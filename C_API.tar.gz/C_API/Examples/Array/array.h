//
//  array.h
//  Array
//
//  Created by Dave Hayden on 2/24/22.
//  Copyright © 2022 Panic, Inc. All rights reserved.
//

#ifndef array_h
#define array_h

#include <stdio.h>
#include "pd_api.h"

void registerArray(PlaydateAPI* pd);

#endif /* array_h */
