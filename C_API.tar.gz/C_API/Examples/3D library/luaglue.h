//
//  3d-glue.h
//  Extension
//
//  Created by Dave Hayden on 9/19/15.
//  Copyright © 2015 Panic, Inc. All rights reserved.
//

#ifndef _d_glue_h
#define _d_glue_h

#include "pd_api.h"

void register3D(PlaydateAPI* playdate);

#endif /* _d_glue_h */
