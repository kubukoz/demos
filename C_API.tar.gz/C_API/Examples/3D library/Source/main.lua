function playdate.update() end

--import "ztest"
import "knot"
--import "knot-ordered"
--import "icosahedra"
